app.controller("specialCtrl", function ($scope, $routeParams) {
    $scope.title = "SPECIAL MANAGER";
    $scope.id = $routeParams.id;
});