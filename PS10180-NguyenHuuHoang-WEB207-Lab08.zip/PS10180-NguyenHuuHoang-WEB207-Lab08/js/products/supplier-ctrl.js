

app.controller("supplierCtrl", function ($scope, $routeParams) {
    $scope.title = "SUPPLIER MANAGER";
    $scope.id = $routeParams.id;
});
