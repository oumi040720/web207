app.controller("categoryCtrl", function ($scope, $routeParams) {
    $scope.title = "CATEGORY MANAGER";
    $scope.id = $routeParams.id;
});